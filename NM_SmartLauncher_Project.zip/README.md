# NM Smart Launcher

A modern Android launcher concept combining:

- iOS 26-inspired rounded/glass UI
- Nothing OS-inspired dot matrix and minimal widgets
- AMOLED black background
- Dynamic animated wallpaper
- Real installed-app discovery and launching
- Swipe left/right pages using ViewPager2
- BiometricPrompt fingerprint/device-credential lock screen
- Custom notification panel
- NotificationListenerService integration
- Search apps
- Modern bottom dock

## Build

Open this folder in Android Studio.

Recommended:
- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35

Then Sync Project and Run.

## Make it the default launcher

Press Home after installation and choose:

NM Smart Launcher -> Always

or:

Settings -> Apps -> Default apps -> Home app

## Notification panel

Android does not allow an ordinary third-party app to replace the protected system notification shade.

This project therefore implements its own launcher notification panel. To populate it with notifications:

Settings -> Special app access -> Notification access -> NM Smart Launcher -> Allow

## Fingerprint

The project uses AndroidX BiometricPrompt. It does not read or store fingerprint data. Android's secure biometric subsystem performs authentication.

## Important

The app-level lock screen is not a replacement for the Android secure lock screen. The Android secure lock screen remains controlled by the OS.
