package com.nm.smartlauncher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class LauncherPagerAdapter(
    private val context: Context,
    private val pages: List<List<AppInfo>>,
    private val onAppClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<LauncherPagerAdapter.PageHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 8, 16, 110)
        }
        return PageHolder(root)
    }

    override fun onBindViewHolder(holder: PageHolder, position: Int) {
        holder.bind(pages[position])
    }

    override fun getItemCount(): Int = pages.size

    inner class PageHolder(private val root: LinearLayout) :
        RecyclerView.ViewHolder(root) {

        fun bind(apps: List<AppInfo>) {
            root.removeAllViews()

            val grid = GridLayout(context).apply {
                columnCount = 4
                rowCount = 5
                useDefaultMargins = false
            }

            apps.forEach { app ->
                val item = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(4, 8, 4, 8)
                    background = context.glassCard(
                        radius = 20f,
                        fill = Color.argb(28, 255, 255, 255)
                    ).background
                    setOnClickListener { onAppClick(app) }
                }

                val icon = ImageView(context).apply {
                    setImageDrawable(app.icon)
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                }

                val name = TextView(context).apply {
                    text = app.label
                    textSize = 10.5f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }

                item.addView(
                    icon,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        48
                    )
                )

                item.addView(
                    name,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        28
                    )
                )

                val params = GridLayout.LayoutParams().apply {
                    width = 0
                    height = 88
                    columnSpec = GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                    )
                    setMargins(5, 5, 5, 5)
                }

                grid.addView(item, params)
            }

            root.addView(
                grid,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
    }
}
