package com.nm.smartlauncher

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    companion object {
        val notifications =
            mutableListOf<LauncherNotification>()
    }

    private lateinit var root: FrameLayout
    private lateinit var pager: ViewPager2
    private lateinit var pageDots: TextView
    private var notificationPanel: View? = null
    private var locked = true

    private var downY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        makeImmersive()

        root = FrameLayout(this)
        setContentView(root)

        buildLauncher()

        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                200
            )
        }

        showLockScreen()
    }

    private fun makeImmersive() {
        WindowCompatCompat.hideSystemBars(window)
    }

    private fun buildLauncher() {

        root.addView(
            WallpaperView(this),
            FrameLayout.LayoutParams(
                -1,
                -1
            )
        )

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 0)
        }

        root.addView(
            content,
            FrameLayout.LayoutParams(-1, -1)
        )

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val system = TextView(this).apply {
            text = "●  SYSTEM ONLINE"
            textSize = 11f
            setTextColor(Color.rgb(130, 255, 210))
            typeface = Typeface.DEFAULT_BOLD
        }

        val battery = TextView(this).apply {
            text = "97%  ▰"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }

        top.addView(
            system,
            LinearLayout.LayoutParams(0, 42, 1f)
        )

        top.addView(
            battery,
            LinearLayout.LayoutParams(
                90,
                42
            )
        )

        content.addView(top)

        val clock = TextView(this).apply {
            textSize = 43f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }

        content.addView(
            clock,
            LinearLayout.LayoutParams(-1, 62)
        )

        val date = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(145, 155, 180))
            gravity = Gravity.CENTER
        }

        content.addView(
            date,
            LinearLayout.LayoutParams(-1, 30)
        )

        val search = TextView(this).apply {
            text = "⌕   Search apps..."
            textSize = 14f
            setTextColor(Color.rgb(170, 180, 200))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 0, 18, 0)
            background = glassCard(
                radius = 20f,
                fill = Color.argb(38, 255, 255, 255)
            ).background

            setOnClickListener {
                showAppSearch()
            }
        }

        content.addView(
            search,
            LinearLayout.LayoutParams(-1, 54).apply {
                bottomMargin = 8
            }
        )

        val header = TextView(this).apply {
            text = "MY APPS                         SWIPE →"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(5, 5, 5, 5)
        }

        content.addView(
            header,
            LinearLayout.LayoutParams(-1, 34)
        )

        val apps = loadApps()

        val pageSize = 20
        val pages = apps.chunked(pageSize)

        pager = ViewPager2(this)

        pager.adapter =
            LauncherPagerAdapter(
                this,
                pages.ifEmpty { listOf(emptyList()) }
            ) { app ->
                launchApp(app)
            }

        pager.registerOnPageChangeCallback(
            object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateDots(position, pages.size)
                }
            }
        )

        content.addView(
            pager,
            LinearLayout.LayoutParams(
                -1,
                0,
                1f
            )
        )

        pageDots = TextView(this).apply {
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(130, 145, 180))
        }

        content.addView(
            pageDots,
            LinearLayout.LayoutParams(-1, 30)
        )

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(5, 5, 5, 8)
            background = glassCard(
                radius = 25f,
                fill = Color.argb(50, 15, 18, 25)
            ).background
        }

        addDockButton(bottom, "⌂", "Home") {
            pager.setCurrentItem(0, true)
        }

        addDockButton(bottom, "☎", "Phone") {
            openPackage("com.google.android.dialer")
        }

        addDockButton(bottom, "◉", "Notify") {
            showNotificationPanel()
        }

        addDockButton(bottom, "⚙", "Settings") {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }

        content.addView(
            bottom,
            LinearLayout.LayoutParams(
                -1,
                72
            )
        )

        val handler = android.os.Handler(mainLooper)

        val updateTime = object : Runnable {
            override fun run() {
                val now = Date()

                clock.text =
                    SimpleDateFormat(
                        "hh:mm a",
                        Locale.getDefault()
                    ).format(now)

                date.text =
                    SimpleDateFormat(
                        "EEEE, MMMM dd",
                        Locale.getDefault()
                    ).format(now)

                handler.postDelayed(this, 1000)
            }
        }

        handler.post(updateTime)

        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    true
                }

                MotionEvent.ACTION_UP -> {
                    val dy = event.rawY - downY

                    if (dy > 130) {
                        showNotificationPanel()
                    }

                    true
                }

                else -> true
            }
        }

        updateDots(0, pages.size)
    }

    private fun addDockButton(
        parent: LinearLayout,
        icon: String,
        name: String,
        click: () -> Unit
    ) {

        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setOnClickListener { click() }
        }

        val i = TextView(this).apply {
            text = icon
            textSize = 23f
            gravity = Gravity.CENTER
        }

        val t = TextView(this).apply {
            text = name
            textSize = 9f
            setTextColor(Color.rgb(170, 180, 200))
            gravity = Gravity.CENTER
        }

        item.addView(i)
        item.addView(t)

        parent.addView(
            item,
            LinearLayout.LayoutParams(
                0,
                -1,
                1f
            )
        )
    }

    private fun updateDots(position: Int, count: Int) {

        if (!::pageDots.isInitialized) return

        val total = count.coerceAtLeast(1)

        pageDots.text =
            (1..total).joinToString("  ") {
                if (it == position + 1) "●" else "○"
            }
    }

    private fun loadApps(): List<AppInfo> {

        val pm = packageManager

        val intent = Intent(
            Intent.ACTION_MAIN,
            null
        ).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        return pm.queryIntentActivities(
            intent,
            PackageManager.MATCH_ALL
        )
            .filter {
                it.activityInfo.packageName != packageName
            }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.loadIcon(pm)
                )
            }
            .distinctBy {
                it.packageName
            }
            .sortedBy {
                it.label.lowercase()
            }
    }

    private fun launchApp(app: AppInfo) {

        val launchIntent =
            packageManager.getLaunchIntentForPackage(
                app.packageName
            )

        if (launchIntent != null) {
            launchIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
            )

            startActivity(launchIntent)
        }
    }

    private fun openPackage(packageName: String) {

        val intent =
            packageManager.getLaunchIntentForPackage(
                packageName
            )

        if (intent != null) {
            startActivity(intent)
        } else {
            startActivity(
                Intent(
                    Intent.ACTION_DIAL
                )
            )
        }
    }

    private fun showAppSearch() {

        val dialog =
            android.app.AlertDialog.Builder(this)
                .setTitle("Search Apps")
                .create()

        val input =
            android.widget.EditText(this).apply {
                hint = "Type app name..."
                setSingleLine(true)
                setPadding(30, 20, 30, 20)
            }

        dialog.setView(input)

        dialog.setButton(
            android.app.AlertDialog.BUTTON_POSITIVE,
            "Open"
        ) { _, _ ->

            val query =
                input.text.toString()
                    .trim()
                    .lowercase()

            val app =
                loadApps().firstOrNull {
                    it.label.lowercase().contains(query)
                }

            if (app != null) {
                launchApp(app)
            }
        }

        dialog.show()
    }

    private fun showNotificationPanel() {

        notificationPanel?.let {
            root.removeView(it)
            notificationPanel = null
            return
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)

            background = glassCard(
                radius = 30f,
                fill = Color.argb(238, 8, 11, 18)
            ).background

            elevation = 30f
        }

        val title = TextView(this).apply {
            text = "NOTIFICATIONS"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(5, 5, 5, 18)
        }

        panel.addView(title)

        if (notifications.isEmpty()) {

            panel.addView(
                TextView(this).apply {
                    text =
                        "No launcher notifications.\n\nEnable Notification Access in Settings to receive them here."
                    textSize = 13f
                    setTextColor(
                        Color.rgb(
                            155,
                            165,
                            185
                        )
                    )
                    setPadding(5, 10, 5, 20)
                }
            )

            val settings = Button(this).apply {
                text = "Notification Access"
                setOnClickListener {
                    startActivity(
                        Intent(
                            "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"
                        )
                    )
                }
            }

            panel.addView(settings)

        } else {

            notifications.take(8).forEach { n ->

                val card =
                    this.glassCard(
                        radius = 18f,
                        fill = Color.argb(
                            32,
                            255,
                            255,
                            255
                        )
                    )

                val t = label(
                    if (n.title.isBlank())
                        n.packageName
                    else
                        n.title,
                    12f
                )

                t.gravity = Gravity.START

                val body = label(
                    n.text.ifBlank {
                        "Notification"
                    },
                    11f
                )

                body.gravity = Gravity.START
                body.setTextColor(
                    Color.rgb(
                        170,
                        180,
                        200
                    )
                )

                card.addView(t)
                card.addView(body)

                panel.addView(
                    card,
                    LinearLayout.LayoutParams(
                        -1,
                        65
                    ).apply {
                        bottomMargin = 8
                    }
                )
            }
        }

        val params =
            FrameLayout.LayoutParams(
                -1,
                -2
            ).apply {
                gravity = Gravity.TOP
                leftMargin = 10
                rightMargin = 10
                topMargin = 20
            }

        root.addView(panel, params)

        notificationPanel = panel
    }

    private fun showLockScreen() {

        if (!locked) return

        val lock = FrameLayout(this).apply {
            setBackgroundColor(
                Color.rgb(3, 5, 8)
            )
            elevation = 100f
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(30, 30, 30, 30)
        }

        val title = TextView(this).apply {
            text = "NM"
            textSize = 52f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }

        val sub = TextView(this).apply {
            text = "SECURE LAUNCHER"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(
                Color.rgb(
                    120,
                    230,
                    200
                )
            )
        }

        val scan = TextView(this).apply {
            text = "◉"
            textSize = 65f
            gravity = Gravity.CENTER
            setTextColor(
                Color.rgb(
                    0,
                    229,
                    255
                )
            )
            setPadding(0, 35, 0, 20)
        }

        val unlock = Button(this).apply {
            text = "UNLOCK WITH FINGERPRINT"
            setOnClickListener {
                authenticate()
            }
        }

        val hint = TextView(this).apply {
            text =
                "Biometric authentication uses Android's secure biometric system."
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(
                Color.rgb(
                    120,
                    130,
                    150
                )
            )
            setPadding(15, 20, 15, 0)
        }

        box.addView(title)
        box.addView(sub)
        box.addView(scan)
        box.addView(unlock)
        box.addView(hint)

        lock.addView(
            box,
            FrameLayout.LayoutParams(
                -1,
                -1
            )
        )

        root.addView(
            lock,
            FrameLayout.LayoutParams(
                -1,
                -1
            )
        )

        authenticate(lock)
    }

    private fun authenticate(lockView: View? = null) {

        val manager =
            BiometricManager.from(this)

        val can =
            manager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )

        if (
            can !=
            BiometricManager.BIOMETRIC_SUCCESS
        ) {

            if (lockView != null) {

                android.app.AlertDialog.Builder(this)
                    .setTitle("Biometric unavailable")
                    .setMessage(
                        "Fingerprint/biometric is not configured on this device. You can use the device credential if available."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }

            return
        }

        val executor =
            ContextCompat.getMainExecutor(this)

        val prompt =
            BiometricPrompt(
                this,
                executor,
                object :
                    BiometricPrompt.AuthenticationCallback() {

                    override fun onAuthenticationSucceeded(
                        result:
                        BiometricPrompt.AuthenticationResult
                    ) {
                        super.onAuthenticationSucceeded(
                            result
                        )

                        locked = false

                        lockView?.let {
                            root.removeView(it)
                        } ?: run {
                            val last =
                                root.getChildAt(
                                    root.childCount - 1
                                )

                            if (last !== notificationPanel) {
                                root.removeView(last)
                            }
                        }
                    }

                    override fun onAuthenticationError(
                        errorCode: Int,
                        errString: CharSequence
                    ) {
                        super.onAuthenticationError(
                            errorCode,
                            errString
                        )
                    }
                }
            )

        val info =
            BiometricPrompt.PromptInfo.Builder()
                .setTitle(
                    "Unlock NM Smart Launcher"
                )
                .setSubtitle(
                    "Use your fingerprint or device credential"
                )
                .setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
                .build()

        prompt.authenticate(info)
    }

    override fun onBackPressed() {
        if (notificationPanel != null) {
            notificationPanel?.let {
                root.removeView(it)
            }
            notificationPanel = null
            return
        }

        super.onBackPressed()
    }
}

object WindowCompatCompat {

    fun hideSystemBars(window: Window) {

        if (Build.VERSION.SDK_INT >= 30) {

            window.setDecorFitsSystemWindows(
                false
            )

            window.insetsController?.let {

                it.hide(
                    WindowInsets.Type.statusBars() or
                        WindowInsets.Type.navigationBars()
                )

                it.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

        } else {

            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }
}
