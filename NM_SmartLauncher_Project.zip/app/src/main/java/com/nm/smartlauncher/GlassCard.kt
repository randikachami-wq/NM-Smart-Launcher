package com.nm.smartlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

fun Context.glassCard(
    radius: Float = 22f,
    stroke: Int = Color.argb(35, 255, 255, 255),
    fill: Int = Color.argb(34, 255, 255, 255)
): LinearLayout {
    return LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(12, 12, 12, 10)

        background = GradientDrawable().apply {
            cornerRadius = radius
            setColor(fill)
            setStroke(1, stroke)
        }
    }
}

fun Context.label(text: String, size: Float = 11f): TextView {
    return TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        maxLines = 1
    }
}
