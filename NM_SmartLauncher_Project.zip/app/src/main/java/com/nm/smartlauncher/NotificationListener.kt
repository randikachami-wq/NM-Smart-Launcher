package com.nm.smartlauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class LauncherNotification(
    val title: String,
    val text: String,
    val packageName: String
)

class NotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE).orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        MainActivity.notifications.add(
            0,
            LauncherNotification(title, text, sbn.packageName)
        )

        if (MainActivity.notifications.size > 40) {
            MainActivity.notifications.removeLast()
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // The launcher keeps a short local history.
    }
}
