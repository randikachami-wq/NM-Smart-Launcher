package com.nm.smartlauncher

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class WallpaperView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawColor(Color.rgb(3, 5, 8))

        val w = width.toFloat()
        val h = height.toFloat()

        val x1 = w * (0.20f + 0.08f * sin(t).toFloat())
        val y1 = h * 0.18f

        val x2 = w * 0.82f
        val y2 = h * (0.50f + 0.10f * sin(t * 0.7f).toFloat())

        val p1 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                x1, y1, w * .48f,
                Color.argb(75, 70, 100, 255),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
        }

        val p2 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                x2, y2, w * .42f,
                Color.argb(50, 0, 230, 200),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
        }

        canvas.drawCircle(x1, y1, w * .48f, p1)
        canvas.drawCircle(x2, y2, w * .42f, p2)

        // Subtle Nothing-style dot matrix.
        paint.color = Color.argb(22, 255, 255, 255)
        val step = 28f
        var y = 0f
        while (y < h) {
            var x = 0f
            while (x < w) {
                canvas.drawCircle(x, y, 1.1f, paint)
                x += step
            }
            y += step
        }

        t += .008f
        postInvalidateDelayed(16)
    }
}
